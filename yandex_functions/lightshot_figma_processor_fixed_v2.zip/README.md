# ☁️ LightShot & Figma Cover Processor

Автоматический обработчик обложек для LightShot и Figma ссылок в Notion базах.

## 🚀 Деплой в Яндекс.Консоль

### 1. Подготовка файлов
- `handler.py` - основной код функции
- `requirements.txt` - зависимости

### 2. Переменные окружения
```bash
NOTION_TOKEN=your_notion_token
CLOUDFLARE_PROXY=https://api.notion.com
YANDEX_DISK_TOKEN=your_yandex_disk_token
FIGMA_TOKEN=your_figma_token
MATERIALS_DB=1d9ace03-d9ff-8041-91a4-d35aeedcbbd4
TASKS_DB=d09df250-ce7e-4e0d-9fbe-4e036d320def
SUBTASKS_DB=9c5f4269-d614-49b6-a748-5579a3c21da3
IDEAS_DB=ad92a6e2-1485-428c-84de-8587706b3be1
```

### 3. Настройки функции
- **Runtime**: Python 3.9
- **Entry point**: handler.handler
- **Memory**: 512 MB
- **Timeout**: 60 секунд

### 4. Параметры вызова
```json
{
  "max_records": 500,
  "dry_run": false,
  "hours_window": 720
}
```

## 📊 Что делает функция

1. **Сканирует базы**: Материалы, Задачи, Подзадачи, Идеи
2. **Находит записи**: Без обложек с LightShot/Figma URL
3. **Обрабатывает ссылки**:
   - LightShot: Парсит HTML, извлекает изображение
   - Figma: Получает превью через API
4. **Загружает на Яндекс.Диск**: Создает папку notion_covers
5. **Обновляет Notion**: Обложка + URL + Files & Media

## ✅ Готово к деплою! 