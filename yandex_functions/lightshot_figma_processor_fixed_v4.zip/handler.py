#!/usr/bin/env python3
"""
☁️ LIGHTSHOT & FIGMA COVER PROCESSOR - АВТОМАТИЧЕСКИЙ ОБРАБОТЧИК ОБЛОЖЕК
Яндекс.Функция для автоматического добавления обложек из LightShot и Figma ссылок
в базах материалов, задач, подзадач и идей
"""

import os
import json
import asyncio
import aiohttp
import re
import sys
from datetime import datetime
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse, quote

def log(msg, level="INFO", **kwargs):
    """Правильное логирование для Яндекс.Cloud Functions"""
    entry = {"msg": msg, "level": level, "ts": datetime.now().isoformat()}
    entry.update(kwargs)
    sys.stdout.write(json.dumps(entry, ensure_ascii=False) + "\n")
    sys.stdout.flush()

class LightShotFigmaProcessor:
    """Обработчик обложек для LightShot и Figma ссылок"""
    
    def __init__(self):
        # Токены из переменных окружения Yandex Functions
        self.notion_token = os.environ.get("NOTION_TOKEN")
        self.cloudflare_proxy = os.environ.get("CLOUDFLARE_PROXY")
        self.yandex_disk_token = os.environ.get("YANDEX_DISK_TOKEN")
        self.figma_token = os.environ.get("FIGMA_TOKEN")
        
        # Базы данных
        self.materials_db = os.environ.get("MATERIALS_DB", "1d9ace03-d9ff-8041-91a4-d35aeedcbbd4")
        self.tasks_db = os.environ.get("TASKS_DB", "d09df250-ce7e-4e0d-9fbe-4e036d320def")
        self.subtasks_db = os.environ.get("SUBTASKS_DB", "9c5f4269-d614-49b6-a748-5579a3c21da3")
        self.ideas_db = os.environ.get("IDEAS_DB", "ad92a6e2-1485-428c-84de-8587706b3be1")
        
        self.stats = {
            "processed": 0,
            "errors": 0,
            "covers_updated": 0,
            "files_added": 0
        }
        
        log("✅ LightShotFigmaProcessor инициализирован")
    
    def _create_aiohttp_session(self):
        """Создает aiohttp сессию"""
        return aiohttp.ClientSession()

    async def _create_folder_on_yandex_disk(self, folder_path: str) -> bool:
        """Создает папку на Яндекс.Диске"""
        try:
            headers = {
                "Authorization": f"OAuth {self.yandex_disk_token or ''}",
                "Content-Type": "application/json"
            }
            
            url = f"https://cloud-api.yandex.net/v1/disk/resources?path={quote(folder_path)}"
            
            async with aiohttp.ClientSession() as session:
                async with session.put(url, headers=headers) as response:
                    log(f"📁 Создание папки {folder_path}: статус {response.status}")
                    
                    if response.status in [200, 201, 409]:  # 409 = папка уже существует
                        log(f"✅ Папка {folder_path} готова")
                        return True
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка создания папки: {response.status} - {error_text}", "ERROR")
                        return False
                        
        except Exception as e:
            log(f"❌ Ошибка создания папки: {e}", "ERROR")
            return False
    
    async def _get_figma_preview(self, figma_url: str) -> str | None:
        """Получает превью из Figma"""
        try:
            # Извлекаем file_key из URL
            if "figma.com/file/" in figma_url:
                file_key = figma_url.split("figma.com/file/")[1].split("/")[0]
            elif "figma.com/design/" in figma_url:
                file_key = figma_url.split("figma.com/design/")[1].split("/")[0]
            else:
                log(f"❌ Не удалось извлечь file_key из {figma_url}", "ERROR")
                return None
            
            # Получаем информацию о файле
            headers = {"X-Figma-Token": self.figma_token or ""}
            url = f"https://api.figma.com/v1/files/{file_key}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        thumbnail_url = data.get('thumbnailUrl')
                        if thumbnail_url:
                            log(f"✅ Получено превью Figma: {thumbnail_url}")
                            return thumbnail_url
                        else:
                            log("⚠️ Превью не найдено в ответе Figma", "WARNING")
                            return None
                    else:
                        log(f"❌ Ошибка получения превью Figma: {response.status}", "ERROR")
                        return None
                        
        except Exception as e:
            log(f"❌ Ошибка получения превью Figma: {e}", "ERROR")
            return None
    
    async def _handle_lightshot_url(self, url: str, session: aiohttp.ClientSession, headers: dict) -> bytes | None:
        """Специальная обработка LightShot URL для получения реального изображения"""
        try:
            log(f"🔍 Анализирую LightShot URL: {url}")
            
            # Получаем HTML-страницу
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    html_content = await response.text()
                    log(f"📄 Получен HTML размером: {len(html_content)} байт")
                    
                    # Ищем изображение в HTML
                    patterns = [
                        r'<img[^>]+src=["\']([^"\']+\.(?:png|jpg|jpeg|gif|webp))["\'][^>]*>',
                        r'<img[^>]+src=["\']([^"\']+lightshot[^"\']*\.(?:png|jpg|jpeg|gif|webp))["\'][^>]*>',
                        r'<img[^>]+src=["\']([^"\']+prnt[^"\']*\.(?:png|jpg|jpeg|gif|webp))["\'][^>]*>',
                        r'<img[^>]+src=["\']([^"\']+ibb[^"\']*\.(?:png|jpg|jpeg|gif|webp))["\'][^>]*>',
                        r'<img[^>]+src=["\']([^"\']+imgur[^"\']*\.(?:png|jpg|jpeg|gif|webp))["\'][^>]*>'
                    ]
                    
                    for pattern in patterns:
                        matches = re.findall(pattern, html_content, re.IGNORECASE)
                        if matches:
                            image_url = matches[0]
                            log(f"🖼️ Найдено изображение: {image_url}")
                            
                            # Скачиваем изображение
                            async with session.get(image_url, headers=headers) as img_response:
                                if img_response.status == 200:
                                    img_content_type = img_response.headers.get('content-type', '')
                                    if 'image' in img_content_type:
                                        data = await img_response.read()
                                        log(f"✅ Скачано LightShot изображение: {len(data)} байт ({img_content_type})")
                                        return data
                                    else:
                                        log(f"⚠️ LightShot URL не вернул изображение: {img_content_type}")
                                else:
                                    log(f"❌ Ошибка скачивания LightShot изображения: {img_response.status}")
                    
                    log(f"❌ Не найдено изображение в LightShot HTML")
                    return None
                else:
                    log(f"❌ Ошибка получения LightShot HTML: {response.status}")
                    return None
                    
        except Exception as e:
            log(f"❌ Ошибка обработки LightShot: {e}", "ERROR")
            return None
    
    async def _handle_figma_url(self, url: str, session: aiohttp.ClientSession, headers: dict) -> bytes | None:
        """Специальная обработка Figma URL для получения изображения"""
        try:
            log(f"🔍 Анализирую Figma URL: {url}")
            
            # Получаем превью через Figma API
            preview_url = await self._get_figma_preview(url)
            if preview_url:
                log(f"🖼️ Получено превью Figma: {preview_url}")
                
                # Скачиваем изображение по превью
                async with session.get(preview_url, headers=headers) as response:
                    if response.status == 200:
                        content_type = response.headers.get('content-type', '')
                        if 'image' in content_type:
                            data = await response.read()
                            log(f"✅ Скачано Figma изображение: {len(data)} байт ({content_type})")
                            return data
                        else:
                            log(f"⚠️ Figma превью не вернул изображение: {content_type}")
                    else:
                        log(f"❌ Ошибка скачивания Figma превью: {response.status}")
            else:
                log(f"❌ Не удалось получить превью Figma")
            
            return None
                    
        except Exception as e:
            log(f"❌ Ошибка обработки Figma: {e}", "ERROR")
            return None
    
    async def _upload_to_yandex_disk_fixed(self, image_data: bytes, filename: str) -> str | None:
        """Исправленная загрузка файла на Яндекс.Диск с созданием папки"""
        try:
            # Сначала создаем папку
            folder_path = "notion_covers"
            folder_created = await self._create_folder_on_yandex_disk(folder_path)
            
            if not folder_created:
                log("❌ Не удалось создать папку на Яндекс.Диске", "ERROR")
                return None
            
            headers = {
                "Authorization": f"OAuth {self.yandex_disk_token or ''}",
                "Content-Type": "application/octet-stream"
            }
            
            # Создаем уникальное имя файла
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_filename = "".join(c for c in filename if c.isalnum() or c in (' ', '-', '_')).rstrip()
            unique_filename = f"{folder_path}/{safe_filename}_{timestamp}.jpg"
            
            # URL-кодируем имя файла
            encoded_filename = quote(unique_filename)
            url = f"https://cloud-api.yandex.net/v1/disk/resources/upload?path={encoded_filename}&overwrite=true"
            
            log(f"📤 Попытка загрузки: {unique_filename}")
            
            async with aiohttp.ClientSession() as session:
                # Получаем ссылку для загрузки
                async with session.get(url, headers=headers) as response:
                    log(f"📊 Статус получения ссылки: {response.status}")
                    
                    if response.status == 200:
                        upload_data = await response.json()
                        upload_url = upload_data.get('href')
                        
                        if upload_url:
                            log(f"✅ Получена ссылка для загрузки: {upload_url}")
                            
                            # Загружаем файл
                            async with session.put(upload_url, data=image_data) as upload_response:
                                log(f"📊 Статус загрузки: {upload_response.status}")
                                
                                if upload_response.status in [200, 201]:
                                    log(f"✅ Файл загружен, начинаем публикацию...")
                                    # Публикуем файл для получения public_url
                                    publish_url = f"https://cloud-api.yandex.net/v1/disk/resources/publish?path={encoded_filename}"
                                    log(f"📤 Публикуем файл: {publish_url}")
                                    async with session.put(publish_url, headers=headers) as publish_response:
                                        log(f"📊 Статус публикации: {publish_response.status}")
                                        if publish_response.status == 200:
                                            publish_data = await publish_response.json()
                                            log(f"📊 publish_data: {publish_data}")
                                            if 'href' in publish_data:
                                                # Получаем информацию о файле для получения public_url
                                                file_info_url = publish_data['href']
                                                log(f"📋 file_info_url: {file_info_url}")
                                                async with session.get(file_info_url, headers=headers) as file_response:
                                                    log(f"📊 Статус получения file_info: {file_response.status}")
                                                    if file_response.status == 200:
                                                        file_info = await file_response.json()
                                                        log(f"📋 file_info: {file_info}")
                                                        if 'public_url' in file_info:
                                                            public_url = file_info['public_url']
                                                            log(f"📋 public_url: {public_url}")
                                                            
                                                            # Получаем ссылку с disposition=inline для обложек Notion
                                                            if 'sizes' in file_info and file_info['sizes']:
                                                                # Ищем размер DEFAULT или ORIGINAL с disposition=inline
                                                                inline_url = None
                                                                for size_info in file_info['sizes']:
                                                                    if 'url' in size_info and 'disposition=inline' in size_info['url']:
                                                                        inline_url = size_info['url']
                                                                        break
                                                                
                                                                if inline_url:
                                                                    log(f"✅ Используем inline URL для Notion: {inline_url}")
                                                                    return inline_url
                                                                else:
                                                                    log(f"⚠️ Не найден URL с disposition=inline, используем file")
                                                                    direct_file_url = file_info['file']
                                                                    log(f"✅ Используем file для Notion: {direct_file_url}")
                                                                    return direct_file_url
                                                            else:
                                                                log(f"⚠️ Нет sizes в file_info, используем file")
                                                                direct_file_url = file_info['file']
                                                                log(f"✅ Используем file для Notion: {direct_file_url}")
                                                                return direct_file_url
                                                        else:
                                                            log(f"⚠️ Не найден public_url в file_info: {file_info}")
                                                            return None
                                                    else:
                                                        log(f"⚠️ Ошибка получения file_info: {file_response.status}")
                                                        return None
                                            else:
                                                log(f"⚠️ Не найден href в publish_data: {publish_data}")
                                                return None
                                        else:
                                            log(f"⚠️ Ошибка публикации файла: {publish_response.status}")
                                            return None
                                else:
                                    error_text = await upload_response.text()
                                    log(f"❌ Ошибка загрузки на Яндекс.Диск: {upload_response.status} - {error_text}", "ERROR")
                                    return None
                        else:
                            log("❌ Не получена ссылка для загрузки", "ERROR")
                            return None
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка получения ссылки загрузки: {response.status} - {error_text}", "ERROR")
                        return None
                        
        except Exception as e:
            log(f"❌ Ошибка загрузки на Яндекс.Диск: {e}", "ERROR")
            return None
    
    async def _update_notion_cover(self, page_id: str, cover_url: str) -> bool:
        """Обновляет обложку в Notion"""
        try:
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json"
            }
            
            payload = {
                "cover": {
                    "type": "external",
                    "external": {
                        "url": cover_url
                    }
                }
            }
            
            url = f"{self.cloudflare_proxy}/v1/pages/{page_id}"
            
            async with aiohttp.ClientSession() as session:
                async with session.patch(url, json=payload, headers=headers) as response:
                    if response.status == 200:
                        log(f"✅ Обложка обновлена в Notion")
                        return True
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка обновления обложки: {response.status} - {error_text}", "ERROR")
                        return False
                        
        except Exception as e:
            log(f"❌ Ошибка обновления обложки: {e}", "ERROR")
            return False
    
    async def _update_notion_properties(self, page_id: str, original_url: str, cover_url: str) -> bool:
        """Обновляет URL и Files & Media поля в Notion"""
        try:
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json"
            }
            
            # Обновляем URL поле
            url_payload = {
                "properties": {
                    "URL": {
                        "url": original_url
                    }
                }
            }
            
            url = f"{self.cloudflare_proxy}/v1/pages/{page_id}"
            
            async with aiohttp.ClientSession() as session:
                # Обновляем URL
                async with session.patch(url, json=url_payload, headers=headers) as response:
                    if response.status == 200:
                        log(f"✅ URL обновлен в Notion")
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка обновления URL: {response.status} - {error_text}", "ERROR")
                
                # Обновляем Files & Media
                files_payload = {
                    "properties": {
                        "Files & media": {
                            "files": [
                                {
                                    "type": "external",
                                    "external": {
                                        "url": cover_url
                                    },
                                    "name": "cover_image.jpg"
                                }
                            ]
                        }
                    }
                }
                
                async with session.patch(url, json=files_payload, headers=headers) as response:
                    if response.status == 200:
                        log(f"✅ Files & Media обновлены в Notion")
                        return True
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка обновления Files & Media: {response.status} - {error_text}", "ERROR")
                        return False
                        
        except Exception as e:
            log(f"❌ Ошибка обновления свойств: {e}", "ERROR")
            return False
    
    async def _process_single_record_clean(self, session: aiohttp.ClientSession, record: Dict[str, Any], db_name: str, dry_run: bool) -> Dict[str, Any]:
        """Обрабатывает одну запись с исправленной логикой"""
        try:
            page_id = record['id']
            title = record.get('title', 'Без названия')
            url = record.get('url')
            
            log(f"🔄 Обрабатываю запись '{title}' из базы '{db_name}'")
            log(f"📎 URL: {url}")
            
            if not url:
                log(f"❌ Нет URL для записи '{title}'", "ERROR")
                return {"error": "Нет URL", "processed": False}
            
            # Определяем тип URL
            url_type = self._detect_url_type(url)
            log(f"🔍 Тип URL: {url_type}")
            
            # Обрабатываем только LightShot и Figma
            if url_type not in ["lightshot", "figma"]:
                log(f"⚠️ Пропускаем неподдерживаемый тип URL: {url_type}", "WARNING")
                return {"error": f"Неподдерживаемый тип URL: {url_type}", "processed": False}
            
            # Получаем изображение в зависимости от типа
            image_data = None
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
            
            if url_type == "figma":
                image_data = await self._handle_figma_url(url, session, headers)
            elif url_type == "lightshot":
                image_data = await self._handle_lightshot_url(url, session, headers)
            
            if not image_data:
                log(f"❌ Не удалось получить изображение для {url}", "ERROR")
                return {"error": "Не удалось получить изображение", "processed": False}
            
            if dry_run:
                log(f"🔍 DRY RUN: Запись '{title}' будет обработана")
                return {"processed": True, "dry_run": True}
            
            # Загружаем на Яндекс.Диск
            cover_url = await self._upload_to_yandex_disk_fixed(image_data, title)
            if not cover_url:
                log(f"❌ Не удалось загрузить на Яндекс.Диск", "ERROR")
                return {"error": "Не удалось загрузить на Яндекс.Диск", "processed": False}
            
            # Обновляем обложку в Notion
            cover_updated = await self._update_notion_cover(page_id, cover_url)
            
            # Обновляем URL и Files & Media
            properties_updated = await self._update_notion_properties(page_id, url, cover_url)
            
            result = {
                'page_id': page_id,
                'title': title,
                'url': url,
                'db_name': db_name,
                'url_type': url_type,
                'processed': True,
                'cover_updated': cover_updated,
                'properties_updated': properties_updated,
                'cover_url': cover_url
            }
            
            log(f"✅ Запись '{title}' успешно обработана")
            return result
            
        except Exception as e:
            log(f"❌ Ошибка обработки записи '{title}': {e}", "ERROR")
            return {"error": str(e), "processed": False}
    
    def _detect_url_type(self, url: str) -> str:
        """Определяет тип URL - только LightShot и Figma"""
        if "figma.com" in url:
            return "figma"
        elif "prnt.sc" in url or "lightshot.cc" in url:
            return "lightshot"
        else:
            return "unsupported"
    
    async def _get_records_without_covers(self, session: aiohttp.ClientSession, db_id: str, limit: int, hours_window: float = 72) -> List[Dict[str, Any]]:
        """Получает записи с LightShot/Figma URL для обработки обложек"""
        try:
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json"
            }
            
            # Простой запрос без фильтров - получаем все записи
            query_payload = {
                "page_size": limit * 2  # Берем больше записей для лучшей фильтрации
            }
            
            url = f"{self.cloudflare_proxy}/v1/databases/{db_id}/query"
            
            async with session.post(url, json=query_payload, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    results = data.get('results', [])
                    
                    log(f"📊 Получено {len(results)} записей с URL")
                    
                    # Фильтруем записи с LightShot/Figma URL и по времени
                    records_to_process = []
                    for record in results:
                        # Проверяем разные поля URL
                        url_value = None
                        url_fields = ['URL', 'Ссылка', 'Link']
                        
                        for field in url_fields:
                            if field in record['properties']:
                                url_prop = record['properties'][field]
                                if 'url' in url_prop and url_prop['url']:
                                    url_value = url_prop['url']
                                    break
                        
                        # Подробное логирование для отладки
                        title_prop = record['properties'].get('Name', {}).get('title', [])
                        title = title_prop[0].get('plain_text', 'Без названия') if title_prop else 'Без названия'
                        
                        log(f"🔍 Запись '{title}': URL={bool(url_value)}")
                        
                        if url_value:
                            # Проверяем, что это LightShot или Figma
                            url_type = self._detect_url_type(url_value)
                            if url_type in ["lightshot", "figma"]:
                                records_to_process.append({
                                    'id': record['id'],
                                    'url': url_value,
                                    'title': title,
                                    'record': record
                                })
                                
                                log(f"✅ Добавлена для обработки: '{title}' с URL: {url_value} (тип: {url_type})")
                                
                                # Ограничиваем количество записей
                                if len(records_to_process) >= limit:
                                    break
                    
                    log(f"✅ Отфильтровано {len(records_to_process)} записей для обработки")
                    return records_to_process
                else:
                    log(f"❌ Ошибка запроса: {response.status}", "ERROR")
                    return []
                    
        except Exception as e:
            log(f"❌ Ошибка получения записей: {e}", "ERROR")
            return []
    
    async def _find_recent_records_with_covers_check(self, session: aiohttp.ClientSession, db_id: str, limit: int, hours_window: float = 72) -> List[Dict[str, Any]]:
        """Находит недавно обновленные записи с фильтрацией на уровне API"""
        try:
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json"
            }
            
            # Вычисляем время для фильтра (72 часа назад)
            from datetime import datetime, timezone, timedelta
            cutoff_time = datetime.now(timezone.utc) - timedelta(hours=hours_window)
            cutoff_iso = cutoff_time.isoformat()
            
            log(f"🔍 Фильтр по времени: записи обновленные после {cutoff_iso}")
            
            # Запрос с фильтром по времени обновления
            query_payload = {
                "page_size": limit,
                "filter": {
                    "property": "last_edited_time",
                    "last_edited_time": {
                        "after": cutoff_iso
                    }
                },
                "sorts": [
                    {
                        "property": "last_edited_time",
                        "direction": "descending"
                    }
                ]
            }
            
            url = f"{self.cloudflare_proxy}/v1/databases/{db_id}/query"
            
            async with session.post(url, json=query_payload, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    results = data.get('results', [])
                    
                    log(f"📊 Получено {len(results)} записей с фильтром по времени")
                    
                    # Дополнительная фильтрация для проверки обложек
                    recent_records = []
                    for record in results:
                        # Проверяем разные поля URL
                        url_value = None
                        url_fields = ['URL', 'Ссылка', 'Link']
                        
                        for field in url_fields:
                            if field in record['properties']:
                                url_prop = record['properties'][field]
                                if 'url' in url_prop and url_prop['url']:
                                    url_value = url_prop['url']
                                    break
                        
                        has_cover = bool(record.get('cover'))
                        
                        # Подробное логирование
                        title_prop = record['properties'].get('Name', {}).get('title', [])
                        title = title_prop[0].get('plain_text', 'Без названия') if title_prop else 'Без названия'
                        
                        log(f"🔍 Недавняя запись '{title}': URL={bool(url_value)}, Cover={has_cover}")
                        
                        recent_records.append({
                            'id': record['id'],
                            'url': url_value,
                            'title': title,
                            'has_cover': has_cover,
                            'record': record
                        })
                        
                        if len(recent_records) >= limit:
                            break
                    
                    log(f"✅ Найдено {len(recent_records)} недавно обновленных записей")
                    return recent_records
                else:
                    error_text = await response.text()
                    log(f"❌ Ошибка запроса с фильтром: {response.status} - {error_text}", "ERROR")
                    return []
                    
        except Exception as e:
            log(f"❌ Ошибка поиска недавних записей: {e}", "ERROR")
            return []

    async def _process_records_without_covers_only(self, session: aiohttp.ClientSession, db_id: str, limit: int, hours_window: float = 72) -> List[Dict[str, Any]]:
        """Обрабатывает только записи БЕЗ обложек из недавно обновленных"""
        try:
            # Сначала находим все недавно обновленные записи с фильтром API
            recent_records = await self._find_recent_records_with_covers_check(session, db_id, limit * 2, hours_window)
            
            if not recent_records:
                log(f"⚠️ Не найдено недавно обновленных записей")
                return []
            
            # Фильтруем только записи БЕЗ обложек с LightShot/Figma URL
            records_to_process = []
            for record_data in recent_records:
                url_value = record_data.get('url')
                has_cover = record_data.get('has_cover', False)
                title = record_data.get('title', 'Unknown')
                
                log(f"🔍 Проверяю '{title}': URL={bool(url_value)}, Cover={has_cover}")
                
                # Обрабатываем только если НЕТ обложки и ЕСТЬ LightShot/Figma URL
                if url_value and not has_cover:
                    url_type = self._detect_url_type(url_value)
                    if url_type in ["lightshot", "figma"]:
                        records_to_process.append(record_data)
                        log(f"✅ Добавлена для обработки: '{title}' с URL: {url_value} (тип: {url_type})")
                        
                        if len(records_to_process) >= limit:
                            break
                elif has_cover:
                    log(f"⏭️ Пропускаю '{title}' - уже есть обложка")
                elif not url_value:
                    log(f"⏭️ Пропускаю '{title}' - нет URL")
                else:
                    log(f"⏭️ Пропускаю '{title}' - не LightShot/Figma URL")
            
            log(f"✅ Отфильтровано {len(records_to_process)} записей БЕЗ обложек для обработки")
            return records_to_process
            
        except Exception as e:
            log(f"❌ Ошибка обработки записей без обложек: {e}", "ERROR")
            return []

    async def process_screenshots_and_covers(self, max_records: int = 500, dry_run: bool = False, hours_window: float = 72) -> Dict[str, Any]:
        """Обрабатывает скриншоты и обложки для всех баз"""
        log(f"🚀 Начинаю обработку с параметрами: max_records={max_records}, dry_run={dry_run}, hours_window={hours_window}")
        
        # Список баз для обработки
        databases = [
            ("Материалы", self.materials_db),
            ("Задачи", self.tasks_db),
            ("Подзадачи", self.subtasks_db),
            ("Идеи", self.ideas_db)
        ]
        
        total_processed = 0
        total_errors = 0
        total_covers_updated = 0
        total_files_added = 0
        
        async with aiohttp.ClientSession() as session:
            for db_name, db_id in databases:
                log(f"🔍 Обрабатываю базу: {db_name} (ID: {db_id})")
                
                try:
                    # Получаем записи БЕЗ обложек для обработки
                    records = await self._process_records_without_covers_only(session, db_id, max_records, hours_window)
                    
                    if not records:
                        log(f"⚠️ В базе '{db_name}' нет записей БЕЗ обложек для обработки")
                        continue
                    
                    log(f"📊 Найдено {len(records)} записей БЕЗ обложек для обработки в '{db_name}'")
                    
                    # Обрабатываем каждую запись
                    for record_data in records:
                        try:
                            result = await self._process_single_record_clean(
                                session, record_data, db_name, dry_run
                            )
                            
                            if result['success']:
                                total_processed += 1
                                if result.get('cover_updated'):
                                    total_covers_updated += 1
                                if result.get('files_added'):
                                    total_files_added += 1
                            else:
                                total_errors += 1
                                
                        except Exception as e:
                            log(f"❌ Ошибка обработки записи '{record_data.get('title', 'Unknown')}': {e}", "ERROR")
                            total_errors += 1
                            
                except Exception as e:
                    log(f"❌ Ошибка обработки базы '{db_name}': {e}", "ERROR")
                    total_errors += 1
        
        # Итоговая статистика
        result = {
            "processed": total_processed,
            "errors": total_errors,
            "covers_updated": total_covers_updated,
            "files_added": total_files_added
        }
        
        log(f"✅ Успешно обработано: {total_processed}")
        log(f"❌ Ошибок: {total_errors}")
        log(f"🖼️ Обложек обновлено: {total_covers_updated}")
        log(f"📁 Файлов добавлено: {total_files_added}")
        
        return result

    async def process_all_records(self, max_records: int = 500, dry_run: bool = False, hours_window: float = 72) -> Dict[str, Any]:
        """Алиас для process_screenshots_and_covers"""
        return await self.process_screenshots_and_covers(max_records, dry_run, hours_window)

async def handler(event, context):
    """Главная функция для Yandex Cloud Functions"""
    try:
        log("🚀 Запуск LightShot & Figma Cover Processor")
        
        # Параметры из event или значения по умолчанию
        max_records = event.get('max_records', 500)
        dry_run = event.get('dry_run', False)
        hours_window = event.get('hours_window', 72)  # 3 дня
        
        log(f"📋 Параметры: max_records={max_records}, dry_run={dry_run}, hours_window={hours_window}")
        
        processor = LightShotFigmaProcessor()
        
        if not processor.notion_token:
            log("❌ NOTION_TOKEN не найден", "ERROR")
            return {
                "statusCode": 400,
                "body": "NOTION_TOKEN не найден"
            }
        
        # Обрабатываем записи
        result = await processor.process_all_records(max_records, dry_run, hours_window)
        
        log("✅ LightShot & Figma Cover Processor завершен успешно")
        
        return {
            "statusCode": 200,
            "body": json.dumps(result, ensure_ascii=False)
        }
        
    except Exception as e:
        log(f"❌ Критическая ошибка в handler: {e}", "ERROR")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}, ensure_ascii=False)
        }

if __name__ == "__main__":
    # Для локального тестирования
    asyncio.run(handler({}, {})) 