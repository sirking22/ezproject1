#!/usr/bin/env python3
"""
🎯 YANDEX CLOUD FUNCTION - АВТОМАТИЧЕСКИЙ ПРОЦЕССОР ОБЛОЖЕК И СКРИНШОТОВ
Обрабатывает записи с URL без обложек и создает обложки из Figma, скриншотов, Яндекс.Диска
Добавляет функционал для обработки скриншотов из prnt.sc и других сервисов
"""

import json
import asyncio
import aiohttp
import re
import os
import time
import random
from typing import Dict, Any, Optional, List
from urllib.parse import urlparse, parse_qs
import urllib.parse
from urllib.parse import quote

# Загружаем переменные окружения для локального тестирования
try:
    from dotenv import load_dotenv
    # Пытаемся загрузить .env из родительской папки
    load_dotenv(os.path.join(os.path.dirname(__file__), '..', '.env'))
except ImportError:
    pass  # dotenv не установлен, используем системные переменные

async def handler(event, context):
    """Главный обработчик Yandex Cloud Function"""
    try:
        # Логирование запуска
        print(f"🚀 ЗАПУСК ФУНКЦИИ: {context.request_id}")
        
        # Получаем параметры из события или используем дефолтные
        max_records = event.get('max_records', 5)
        dry_run = event.get('dry_run', False)
        process_screenshots = event.get('process_screenshots', True)
        
        # Запускаем процессор
        processor = AutoCoverProcessor()
        
        if process_screenshots:
            result = await processor.process_screenshots_and_covers(max_records, dry_run)
        else:
            result = await processor.process_all_records(max_records, dry_run)
        
        # Возвращаем результат
        return {
            'statusCode': 200,
            'body': json.dumps(result, ensure_ascii=False, indent=2)
        }
        
    except Exception as e:
        print(f"❌ ОШИБКА В ФУНКЦИИ: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'request_id': context.request_id
            }, ensure_ascii=False)
        }

class AutoCoverProcessor:
    """Автоматический процессор обложек и скриншотов для Yandex Functions"""
    
    def __init__(self):
        # Токены из переменных окружения Yandex Functions
        self.notion_token = os.environ.get("NOTION_TOKEN")
        self.cloudflare_proxy = os.environ.get("CLOUDFLARE_PROXY")
        self.figma_token = os.environ.get("FIGMA_TOKEN")
        self.yandex_token = os.environ.get("YANDEX_DISK_TOKEN")
        
        # Загрузка переменных из .env если не найдены
        if not self.yandex_token:
            try:
                from dotenv import load_dotenv
                load_dotenv('../.env')
                self.yandex_token = os.environ.get("YANDEX_DISK_TOKEN")
                print(f"✅ Yandex токен загружен: {self.yandex_token[:20]}..." if self.yandex_token else "❌ Yandex токен не найден")
            except:
                print("❌ Не удалось загрузить .env файл")
        
        # ID баз данных
        self.materials_db = os.environ.get("MATERIALS_DB", "1d9ace03-d9ff-8041-91a4-d35aeedcbbd4")
        self.tasks_db = os.environ.get("DESIGN_TASKS_DB", "d09df250-ce7e-4e0d-9fbe-4e036d320def")
        self.subtasks_db = os.environ.get("SUBTASKS_DB", "9c5f4269-d614-49b6-a748-5579a3c21da3")
        
        if not all([self.notion_token, self.cloudflare_proxy]):
            raise ValueError("❌ Отсутствуют обязательные переменные окружения")
        
        print(f"✅ Инициализация: Notion ✓, Proxy ✓, Figma {'✓' if self.figma_token else '❌'}, Yandex {'✓' if self.yandex_token else '❌'}")

    async def process_screenshots_and_covers(self, max_records: int = 5, dry_run: bool = False) -> Dict[str, Any]:
        """Обработка скриншотов и обложек"""
        
        print(f"🔍 ПОИСК СКРИНШОТОВ И ЗАПИСЕЙ БЕЗ ОБЛОЖЕК (лимит: {max_records})")
        
        results = {
            "processed_count": 0,
            "updated_covers": 0,
            "added_files": 0,
            "screenshots_processed": 0,
            "errors": [],
            "details": []
        }
        
        async with aiohttp.ClientSession() as session:
            # Обработка каждой базы
            databases = [
                ("Материалы", self.materials_db),
                ("Задачи", self.tasks_db),
                ("Подзадачи", self.subtasks_db)
            ]
            
            for db_name, db_id in databases:
                try:
                    # Получаем записи со скриншотами и без обложек
                    records = await self._get_records_with_screenshots_and_no_covers(session, db_id, max_records)
                    print(f"📊 {db_name}: найдено {len(records)} записей для обработки")
                    
                    for record in records:
                        if results["processed_count"] >= max_records:
                            break
                            
                        try:
                            result = await self._process_single_record_with_screenshots(session, record, db_name, dry_run)
                            results["details"].append(result)
                            results["processed_count"] += 1
                            
                            if result.get("cover_updated"):
                                results["updated_covers"] += 1
                            if result.get("files_added"):
                                results["added_files"] += 1
                            if result.get("screenshots_processed"):
                                results["screenshots_processed"] += 1
                                
                        except Exception as e:
                            error_msg = f"Ошибка обработки записи {record.get('id', 'unknown')}: {e}"
                            print(f"❌ {error_msg}")
                            results["errors"].append(error_msg)
                            
                except Exception as e:
                    error_msg = f"Ошибка обработки базы {db_name}: {e}"
                    print(f"❌ {error_msg}")
                    results["errors"].append(error_msg)
        
        print(f"✅ ЗАВЕРШЕНО: обработано {results['processed_count']}, обложек {results['updated_covers']}, файлов {results['added_files']}, скриншотов {results['screenshots_processed']}")
        return results

    async def process_all_records(self, max_records: int = 5, dry_run: bool = False) -> Dict[str, Any]:
        """Обработка всех записей с URL без обложек (старый метод)"""
        
        print(f"🔍 ПОИСК ЗАПИСЕЙ БЕЗ ОБЛОЖЕК (лимит: {max_records})")
        
        results = {
            "processed_count": 0,
            "updated_covers": 0,
            "added_files": 0,
            "errors": [],
            "details": []
        }
        
        async with aiohttp.ClientSession() as session:
            # Обработка каждой базы
            databases = [
                ("Материалы", self.materials_db),
                ("Задачи", self.tasks_db),
                ("Подзадачи", self.subtasks_db)
            ]
            
            for db_name, db_id in databases:
                try:
                    records = await self._get_records_without_covers(session, db_id, max_records)
                    print(f"📊 {db_name}: найдено {len(records)} записей без обложек")
                    
                    for record in records:
                        if results["processed_count"] >= max_records:
                            break
                            
                        try:
                            result = await self._process_single_record(session, record, db_name, dry_run)
                            results["details"].append(result)
                            results["processed_count"] += 1
                            
                            if result.get("cover_updated"):
                                results["updated_covers"] += 1
                            if result.get("files_added"):
                                results["added_files"] += 1
                                
                        except Exception as e:
                            error_msg = f"Ошибка обработки записи {record.get('id', 'unknown')}: {e}"
                            print(f"❌ {error_msg}")
                            results["errors"].append(error_msg)
                            
                except Exception as e:
                    error_msg = f"Ошибка обработки базы {db_name}: {e}"
                    print(f"❌ {error_msg}")
                    results["errors"].append(error_msg)
        
        print(f"✅ ЗАВЕРШЕНО: обработано {results['processed_count']}, обложек {results['updated_covers']}, файлов {results['added_files']}")
        return results

    async def _get_records_with_screenshots_and_no_covers(self, session: aiohttp.ClientSession, db_id: str, limit: int) -> List[Dict[str, Any]]:
        """Получение записей со скриншотами и без обложек"""
        
        url = f"{self.cloudflare_proxy}/v1/databases/{db_id}/query"
        headers = {
            "Authorization": f"Bearer {self.notion_token}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28"
        }
        
        # Получаем все записи (без фильтра по Cover, так как он может не работать)
        payload = {
            "page_size": limit * 2  # Увеличиваем лимит для фильтрации
        }
        
        async with session.post(url, headers=headers, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                all_records = data.get("results", [])
                
                # Фильтруем записи со скриншотами и без обложек
                filtered_records = []
                for record in all_records:
                    if len(filtered_records) >= limit:
                        break
                        
                    # Проверяем наличие скриншотов
                    has_screenshots = self._has_screenshot_urls(record)
                    # Проверяем отсутствие обложки
                    has_cover = record.get("cover") is not None
                    
                    if has_screenshots and not has_cover:
                        filtered_records.append(record)
                
                return filtered_records
            else:
                print(f"❌ Ошибка получения записей: {response.status}")
                return []

    def _has_screenshot_urls(self, record: Dict[str, Any]) -> bool:
        """Проверка наличия скриншотов в записи"""
        urls = self._extract_urls(record)
        for url in urls:
            if self._is_screenshot_url(url):
                return True
        return False

    def _is_screenshot_url(self, url: str) -> bool:
        """Определение является ли URL скриншотом"""
        screenshot_domains = [
            "prnt.sc", "prntscr.com", "lightshot.cc", "lightshot.com",
            "imgur.com", "postimages.org", "ibb.co", "imgbb.com",
            "gyazo.com", "puush.me", "sharex.com"
        ]
        
        parsed_url = urlparse(url)
        domain = parsed_url.netloc.lower()
        
        # Проверяем домены скриншотов
        for screenshot_domain in screenshot_domains:
            if screenshot_domain in domain:
                return True
        
        # Проверяем расширения изображений
        if any(ext in url.lower() for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']):
            return True
            
        return False

    async def _get_records_without_covers(self, session: aiohttp.ClientSession, db_id: str, limit: int) -> List[Dict[str, Any]]:
        """Получение записей без обложек из базы"""
        
        url = f"{self.cloudflare_proxy}/v1/databases/{db_id}/query"
        headers = {
            "Authorization": f"Bearer {self.notion_token}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28"
        }
        
        payload = {
            "filter": {
                "property": "Cover",
                "files": {"is_empty": True}
            },
            "page_size": limit
        }
        
        async with session.post(url, headers=headers, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                return data.get("results", [])
            else:
                print(f"❌ Ошибка получения записей: {response.status}")
                return []

    async def _process_single_record_with_screenshots(self, session: aiohttp.ClientSession, record: Dict[str, Any], db_name: str, dry_run: bool) -> Dict[str, Any]:
        """Обработка одной записи со скриншотами"""
        
        record_id = record["id"]
        title = self._extract_title(record)
        urls = self._extract_urls(record)
        
        print(f"🔍 Обработка записи: {record_id}")
        print(f"📝 Название: {title}")
        print(f"🔗 URLs: {urls}")
        
        result = {
            "id": record_id,
            "title": title,
            "database": db_name,
            "urls_found": len(urls),
            "cover_updated": False,
            "files_added": False,
            "screenshots_processed": False,
            "dry_run": dry_run
        }
        
        if not urls:
            result["status"] = "no_urls"
            return result
        
        # Обработка скриншотов
        screenshot_urls = [url for url in urls if self._is_screenshot_url(url)]
        if screenshot_urls:
            try:
                screenshot_result = await self._process_screenshots(session, record_id, title, screenshot_urls, dry_run)
                if screenshot_result:
                    result.update(screenshot_result)
                    result["screenshots_processed"] = True
                    return result
            except Exception as e:
                print(f"❌ Ошибка обработки скриншотов: {e}")
        
        # Обработка обычных URL для обложек
        for url in urls:
            url_type = self._detect_url_type(url)
            if url_type == "unknown":
                continue
                
            try:
                # Специальная обработка для Яндекс.Диск и дизайн-файлов
                if url_type == "yandex_disk" or (url_type == "design_file" and "disk.yandex" in url):
                    # Сохраняем оригинальную ссылку для URL поля
                    original_url = url
                    print(f"✅ Оригинальная Яндекс.Диск ссылка: {original_url}")
                    
                    # Проверяем, что это ссылка на изображение с /i/
                    if '/i/' not in url:
                        # Преобразуем в ссылку на изображение
                        url = url.replace('/d/', '/i/')
                        print(f"✅ Преобразована в ссылку на изображение: {url}")
                    
                    # Получаем превью изображения
                    preview_data = await self._get_yandex_disk_preview(session, url)
                    if preview_data and len(preview_data) > 0:
                        print(f"✅ Превью получено, размер: {len(preview_data)} байт")
                        
                        # Загружаем превью на Яндекс.Диск
                        print(f"⚠️ Загружаем превью на Яндекс.Диск")
                        await self._create_yandex_folder(session, "/previews")
                        
                        # Генерация уникального имени файла
                        timestamp = int(time.time() * 1000000)  # микросекунды
                        random_num = random.randint(1000, 9999)
                        safe_title = re.sub(r'[^\w\s-]', '', title)[:30]
                        filename = f"{safe_title}_preview_{timestamp}_{random_num}.png"
                        yandex_path = f"/previews/{filename}"
                        
                        # Получение URL для загрузки
                        upload_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/upload"
                        params = {"path": yandex_path, "overwrite": "true"}
                        headers = {"Authorization": f"OAuth {self.yandex_token}"}
                        
                        try:
                            async with session.get(upload_url_api, params=params, headers=headers) as response:
                                if response.status == 200:
                                    data = await response.json()
                                    upload_url = data.get("href")
                                    
                                    if upload_url:
                                        # Загрузка файла
                                        async with session.put(upload_url, data=preview_data) as upload_response:
                                            if upload_response.status in [201, 202]:
                                                # Публикация файла
                                                publish_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/publish"
                                                publish_params = {"path": yandex_path}
                                                
                                                async with session.put(publish_url_api, params=publish_params, headers=headers) as publish_response:
                                                    if publish_response.status == 200:
                                                        # Получение публичной ссылки
                                                        public_url_api = f"https://cloud-api.yandex.net/v1/disk/resources"
                                                        public_params = {"path": yandex_path, "fields": "public_url"}
                                                        
                                                        async with session.get(public_url_api, params=public_params, headers=headers) as public_response:
                                                            if public_response.status == 200:
                                                                public_data = await public_response.json()
                                                                public_url = public_data.get("public_url")
                                                                
                                                                if public_url:
                                                                    # Используем прямую /i/ ссылку
                                                                    direct_url = public_url.replace("https://disk.yandex.ru/d/", "https://disk.yandex.ru/i/")
                                                                    print(f"✅ Загружено на Яндекс.Диск: {direct_url}")
                                                                    
                                                                    # Устанавливаем обложку с прямой ссылкой
                                                                    await self._update_record_cover(session, record_id, direct_url)
                                                                    result["cover_updated"] = True
                                                                    print(f"✅ Обложка успешно установлена: {direct_url}")
                                                                    
                                                                    # Добавление в Files & media для материалов - используем оригинальную ссылку
                                                                    if db_name == "Материалы":
                                                                        await self._add_to_files_media(session, record_id, original_url, title)
                                                                        result["files_added"] = True
                                                                        print(f"✅ Файл добавлен в Files & media: {original_url}")
                                                                    
                                                                    result["status"] = "success"
                                                                    return result
                        except Exception as e:
                            print(f"❌ Ошибка при загрузке на Яндекс.Диск: {e}")
                    
                    # Если не удалось загрузить на Яндекс.Диск, пробуем через Cloudflare
                    try:
                        # Проксируем через Cloudflare
                        proxied_url = f"{self.cloudflare_proxy}/proxy?url={quote(url)}"
                        print(f"⚠️ Пробуем через Cloudflare прокси: {proxied_url}")
                        
                        # Получаем изображение через прокси
                        async with session.get(proxied_url) as response:
                            if response.status == 200:
                                image_data = await response.read()
                                print(f"✅ Получено изображение через прокси: {len(image_data)} байт")
                                
                                # Загружаем на Яндекс.Диск как новый файл
                                print(f"⚠️ Загружаем изображение на Яндекс.Диск через прокси")
                                await self._create_yandex_folder(session, "/screenshots")
                                
                                # Генерация уникального имени файла
                                timestamp = int(time.time() * 1000000)  # микросекунды
                                random_num = random.randint(1000, 9999)
                                safe_title = re.sub(r'[^\w\s-]', '', title)[:30]
                                filename = f"{safe_title}_proxy_{timestamp}_{random_num}.png"
                                yandex_path = f"/screenshots/{filename}"
                                
                                # Получение URL для загрузки
                                upload_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/upload"
                                params = {"path": yandex_path, "overwrite": "true"}
                                headers = {"Authorization": f"OAuth {self.yandex_token}"}
                                
                                async with session.get(upload_url_api, params=params, headers=headers) as upload_response:
                                    if upload_response.status == 200:
                                        data = await upload_response.json()
                                        upload_url = data.get("href")
                                        
                                        if upload_url:
                                            # Загрузка файла
                                            async with session.put(upload_url, data=image_data) as put_response:
                                                if put_response.status in [201, 202]:
                                                    # Публикация файла
                                                    publish_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/publish"
                                                    publish_params = {"path": yandex_path}
                                                    
                                                    async with session.put(publish_url_api, params=publish_params, headers=headers) as publish_response:
                                                        if publish_response.status == 200:
                                                            # Получение публичной ссылки
                                                            public_url_api = f"https://cloud-api.yandex.net/v1/disk/resources"
                                                            public_params = {"path": yandex_path, "fields": "public_url"}
                                                            
                                                            async with session.get(public_url_api, params=public_params, headers=headers) as public_response:
                                                                if public_response.status == 200:
                                                                    public_data = await public_response.json()
                                                                    public_url = public_data.get("public_url")
                                                                    
                                                                    if public_url:
                                                                        # Используем прямую /i/ ссылку
                                                                        direct_url = public_url.replace("https://disk.yandex.ru/d/", "https://disk.yandex.ru/i/")
                                                                        print(f"✅ Загружено на Яндекс.Диск через прокси: {direct_url}")
                                                                        
                                                                        # Устанавливаем обложку с прямой ссылкой
                                                                        await self._update_record_cover(session, record_id, direct_url)
                                                                        result["cover_updated"] = True
                                                                        print(f"✅ Обложка успешно установлена через прокси: {direct_url}")
                                                                        
                                                                        # Добавление в Files & media для матералов - используем оригинальную ссылку
                                                                        if db_name == "Материалы":
                                                                            await self._add_to_files_media(session, record_id, original_url, title)
                                                                            result["files_added"] = True
                                                                            print(f"✅ Файл добавлен в Files & media: {original_url}")
                                                                        
                                                                        result["status"] = "success"
                                                                        return result
                    except Exception as e:
                        print(f"❌ Ошибка при установке обложки через прокси: {e}")
                    
                    print(f"❌ Не удалось установить обложку для Яндекс.Диск: {url}")
                    # Продолжаем выполнение для поиска других URL
                
                # Специальная обработка для дизайн-файлов не на Яндекс.Диске
                if url_type == "design_file":
                    if dry_run:
                        result["status"] = "would_update"
                        result["preview_size"] = 0
                        return result
                    
                    # Используем оригинальную ссылку как обложку
                    await self._update_record_cover(session, record_id, url)
                    result["cover_updated"] = True
                    
                    # Добавление в Files & media для материалов
                    if db_name == "Материалы":
                        await self._add_to_files_media(session, record_id, url, title)
                        result["files_added"] = True
                    
                    result["status"] = "success"
                    return result
                
                # Обычная обработка для других типов URL
                preview_data = await self._get_preview_from_url(session, url, url_type)
                if not preview_data:
                    continue
                
                if dry_run:
                    result["status"] = "would_update"
                    result["preview_size"] = len(preview_data) if preview_data else 0
                    return result
                
                # Загрузка на Яндекс.Диск и обновление записи
                yandex_url = await self._upload_to_yandex_disk(session, preview_data, title, url_type)
                if yandex_url:
                    await self._update_record_cover(session, record_id, yandex_url)
                    result["cover_updated"] = True
                    result["yandex_url"] = yandex_url
                    
                    # Добавление в Files & media для материалов
                    if db_name == "Материалы":
                        await self._add_to_files_media(session, record_id, yandex_url, title)
                        result["files_added"] = True
                
                result["status"] = "success"
                return result
                
            except Exception as e:
                print(f"❌ Ошибка обработки URL {url}: {e}")
                continue
        
        result["status"] = "no_valid_urls"
        return result

    async def _process_screenshots(self, session: aiohttp.ClientSession, record_id: str, title: str, screenshot_urls: List[str], dry_run: bool) -> Optional[Dict[str, Any]]:
        """Обработка скриншотов"""
        
        for screenshot_url in screenshot_urls:
            try:
                # Получение изображения скриншота
                image_data = await self._get_screenshot_image(session, screenshot_url)
                if not image_data:
                    continue
                
                if dry_run:
                    return {
                        "status": "would_process_screenshot",
                        "preview_size": len(image_data),
                        "screenshot_url": screenshot_url
                    }
                
                # Загрузка на Яндекс.Диск в папку /screenshots
                yandex_url = await self._upload_screenshot_to_yandex_disk(session, image_data, title, screenshot_url)
                if yandex_url:
                    # Обновление обложки
                    await self._update_record_cover(session, record_id, yandex_url)
                    
                    # Добавление в Files & media
                    await self._add_to_files_media(session, record_id, yandex_url, f"Скриншот - {title}")
                    
                    # Обновление URL поля на Яндекс.Диск ссылку
                    await self._update_url_field(session, record_id, screenshot_url, yandex_url)
                    
                    return {
                        "status": "screenshot_processed",
                        "cover_updated": True,
                        "files_added": True,
                        "yandex_url": yandex_url,
                        "original_url": screenshot_url
                    }
                    
            except Exception as e:
                print(f"❌ Ошибка обработки скриншота {screenshot_url}: {e}")
                continue
        
        return None

    async def _get_screenshot_image(self, session: aiohttp.ClientSession, screenshot_url: str) -> Optional[bytes]:
        """Получение изображения скриншота"""
        
        try:
            # Для prnt.sc и подобных сервисов
            if "prnt.sc" in screenshot_url or "prntscr.com" in screenshot_url:
                return await self._get_prntsc_image(session, screenshot_url)
            
            # Для других сервисов - прямая загрузка
            timeout = aiohttp.ClientTimeout(total=30)
            async with session.get(screenshot_url, timeout=timeout) as response:
                if response.status == 200:
                    return await response.read()
                    
        except Exception as e:
            print(f"❌ Ошибка получения скриншота: {e}")
        
        return None

    async def _get_prntsc_image(self, session: aiohttp.ClientSession, prntsc_url: str) -> Optional[bytes]:
        """Получение изображения с prnt.sc"""
        
        try:
            # Заголовки браузера для обхода Cloudflare
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            # Получаем HTML страницу
            timeout = aiohttp.ClientTimeout(total=30)
            async with session.get(prntsc_url, headers=headers, timeout=timeout) as response:
                if response.status == 200:
                    html = await response.text()
                    
                    # Ищем прямую ссылку на изображение
                    img_patterns = [
                        r'<img[^>]+src=["\']([^"\']+\.(?:png|jpg|jpeg|gif))["\'][^>]*>',
                        r'<img[^>]+src=["\'](https://[^"\']+\.(?:png|jpg|jpeg|gif))["\'][^>]*>',
                        r'data-src=["\']([^"\']+\.(?:png|jpg|jpeg|gif))["\']',
                        r'data-original=["\']([^"\']+\.(?:png|jpg|jpeg|gif))["\']'
                    ]
                    
                    for pattern in img_patterns:
                        matches = re.findall(pattern, html, re.IGNORECASE)
                        for match in matches:
                            if match.startswith('http'):
                                # Загружаем изображение
                                async with session.get(match, headers=headers, timeout=timeout) as img_response:
                                    if img_response.status == 200:
                                        return await img_response.read()
                            elif match.startswith('/'):
                                # Относительный путь
                                base_url = f"https://{urlparse(prntsc_url).netloc}"
                                full_url = base_url + match
                                async with session.get(full_url, headers=headers, timeout=timeout) as img_response:
                                    if img_response.status == 200:
                                        return await img_response.read()
                                        
        except Exception as e:
            print(f"❌ Ошибка получения prnt.sc изображения: {e}")
        
        return None

    async def _upload_screenshot_to_yandex_disk(self, session: aiohttp.ClientSession, image_data: bytes, title: str, original_url: str) -> Optional[str]:
        """Загрузка скриншота на Яндекс.Диск в папку /screenshots"""
        if not self.yandex_token:
            return None
            
        try:
            # Создаем папку /screenshots если не существует
            await self._create_yandex_folder(session, "/screenshots")
            
            # Генерация уникального имени файла
            timestamp = int(time.time() * 1000000)  # микросекунды
            random_num = random.randint(1000, 9999)
            safe_title = re.sub(r'[^\w\s-]', '', title)[:30]
            
            # Определяем расширение из URL или используем PNG
            ext = "png"
            if any(ext in original_url.lower() for ext in ['.jpg', '.jpeg']):
                ext = "jpg"
            elif '.gif' in original_url.lower():
                ext = "gif"
            elif '.webp' in original_url.lower():
                ext = "webp"
            
            filename = f"{safe_title}_screenshot_{timestamp}_{random_num}.{ext}"
            yandex_path = f"/screenshots/{filename}"
            
            # Получение URL для загрузки
            upload_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/upload"
            params = {"path": yandex_path, "overwrite": "true"}
            headers = {"Authorization": f"OAuth {self.yandex_token}"}
            
            async with session.get(upload_url_api, params=params, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    upload_url = data.get("href")
                    
                    if upload_url:
                        # Загрузка файла
                        async with session.put(upload_url, data=image_data) as upload_response:
                            if upload_response.status in [201, 202]:
                                # Получение публичной ссылки
                                return await self._get_yandex_public_url(session, yandex_path)
                                
        except Exception as e:
            print(f"❌ Ошибка загрузки скриншота на Яндекс.Диск: {e}")
        
        return None

    async def _create_yandex_folder(self, session: aiohttp.ClientSession, folder_path: str):
        """Создание папки на Яндекс.Диске"""
        try:
            api_url = f"https://cloud-api.yandex.net/v1/disk/resources"
            params = {"path": folder_path}
            headers = {"Authorization": f"OAuth {self.yandex_token}"}
            
            async with session.put(api_url, params=params, headers=headers) as response:
                if response.status in [201, 409]:  # 409 = папка уже существует
                    print(f"✅ Папка {folder_path} готова")
                else:
                    print(f"⚠️ Статус создания папки {folder_path}: {response.status}")
                    
        except Exception as e:
            print(f"❌ Ошибка создания папки {folder_path}: {e}")

    async def _update_url_field(self, session: aiohttp.ClientSession, record_id: str, old_url: str, new_url: str):
        """Обновление URL поля на ссылку Яндекс.Диска"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{record_id}"
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Content-Type": "application/json",
                "Notion-Version": "2022-06-28"
            }
            
            # Находим поле с URL и обновляем его
            # Это может быть поле URL, Link или другое
            payload = {
                "properties": {
                    "URL": {
                        "url": new_url
                    }
                }
            }
            
            async with session.patch(url, headers=headers, json=payload) as response:
                if response.status == 200:
                    print(f"✅ URL обновлен для записи {record_id}")
                else:
                    print(f"❌ Ошибка обновления URL: {response.status}")
                    
        except Exception as e:
            print(f"❌ Ошибка обновления URL: {e}")

    async def _process_single_record(self, session: aiohttp.ClientSession, record: Dict[str, Any], db_name: str, dry_run: bool) -> Dict[str, Any]:
        """Обработка одной записи (старый метод)"""
        
        record_id = record["id"]
        title = self._extract_title(record)
        urls = self._extract_urls(record)
        
        print(f"🔍 Обработка записи: {record_id}")
        print(f"📝 Название: {title}")
        print(f"🔗 URLs: {urls}")
        
        result = {
            "id": record_id,
            "title": title,
            "database": db_name,
            "urls_found": len(urls),
            "cover_updated": False,
            "files_added": False,
            "dry_run": dry_run
        }
        
        if not urls:
            result["status"] = "no_urls"
            return result
        
        # Обработка первого подходящего URL
        for url in urls:
            url_type = self._detect_url_type(url)
            if url_type == "unknown":
                continue
                
            try:
                # Получение превью
                preview_data = await self._get_preview_from_url(session, url, url_type)
                if not preview_data:
                    continue
                
                if dry_run:
                    result["status"] = "would_update"
                    result["preview_size"] = len(preview_data) if preview_data else 0
                    return result
                
                # Загрузка на Яндекс.Диск и обновление записи
                yandex_url = await self._upload_to_yandex_disk(session, preview_data, title, url_type)
                if yandex_url:
                    await self._update_record_cover(session, record_id, yandex_url)
                    result["cover_updated"] = True
                    result["yandex_url"] = yandex_url
                    
                    # Добавление в Files & media для материалов
                    if db_name == "Материалы":
                        await self._add_to_files_media(session, record_id, yandex_url, title)
                        result["files_added"] = True
                
                result["status"] = "success"
                return result
                
            except Exception as e:
                print(f"❌ Ошибка обработки URL {url}: {e}")
                continue
        
        result["status"] = "no_valid_urls"
        return result

    def _extract_title(self, record: Dict[str, Any]) -> str:
        """Извлечение названия записи"""
        try:
            title_prop = record.get("properties", {}).get("Name", {})
            if title_prop.get("type") == "title":
                return "".join([t.get("plain_text", "") for t in title_prop.get("title", [])])
            return "Без названия"
        except:
            return "Без названия"

    def _extract_urls(self, record: Dict[str, Any]) -> List[str]:
        """Извлечение URL из записи"""
        urls = []
        
        try:
            properties = record.get("properties", {})
            
            # Поиск в URL полях
            for prop_name, prop_data in properties.items():
                if prop_data.get("type") == "url" and prop_data.get("url"):
                    urls.append(prop_data["url"])
                
                # Поиск в rich_text полях
                elif prop_data.get("type") == "rich_text":
                    for text_obj in prop_data.get("rich_text", []):
                        if text_obj.get("href"):
                            urls.append(text_obj["href"])
                        
                        # Поиск URL в тексте
                        plain_text = text_obj.get("plain_text", "")
                        url_pattern = r'https?://[^\s<>"\'`|()[\]{}]+'
                        found_urls = re.findall(url_pattern, plain_text)
                        urls.extend(found_urls)
        
        except Exception as e:
            print(f"❌ Ошибка извлечения URL: {e}")
        
        return list(set(urls))  # Удаляем дубли

    def _detect_url_type(self, url: str) -> str:
        """Определение типа URL"""
        if "figma.com" in url:
            return "figma"
        elif any(domain in url for domain in ["disk.yandex.", "yadi.sk", "cloud-api.yandex.net"]):
            return "yandex_disk"
        elif any(domain in url for domain in ["prnt.sc", "prntscr.com", "lightshot.com"]):
            return "screenshot"
        elif any(ext in url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp']):
            return "direct_image"
        # Дизайн-форматы
        elif any(ext in url.lower() for ext in ['.psd', '.ai', '.pdf', '.cdr', '.xd', '.sketch', '.eps', '.indd', '.aep', '.afdesign', '.afphoto', '.blend']):
            return "design_file"
        return "unknown"

    def _find_first_frame_id(self, document: Dict[str, Any]) -> Optional[str]:
        """Поиск первого фрейма в документе Figma"""
        def search_frames(node: Dict[str, Any]) -> Optional[str]:
            if node.get("type") == "FRAME":
                return node.get("id")
            
            children = node.get("children", [])
            for child in children:
                result = search_frames(child)
                if result:
                    return result
            
            return None
        
        return search_frames(document)

    async def _get_preview_from_url(self, session: aiohttp.ClientSession, url: str, url_type: str) -> Optional[bytes]:
        """Получение превью из URL"""
        
        if url_type == "figma":
            return await self._get_figma_preview(session, url)
        elif url_type == "screenshot":
            return await self._get_screenshot_image(session, url)
        elif url_type == "direct_image":
            return await self._download_image(session, url)
        elif url_type == "yandex_disk":
            # Для Яндекс.Диск проверяем доступность
            return await self._get_yandex_disk_preview(session, url)
        elif url_type == "design_file":
            # Для дизайн-файлов пробуем получить превью через Яндекс.Диск, если это ссылка на Яндекс
            if "disk.yandex" in url:
                return await self._get_yandex_disk_preview(session, url)
            # В противном случае, просто возвращаем True, чтобы обрабатывать как обычный файл
            return b"design_file_placeholder"
        
        return None

    async def _get_figma_preview(self, session: aiohttp.ClientSession, url: str) -> Optional[bytes]:
        """Получение превью из Figma"""
        if not self.figma_token:
            return None
            
        try:
            # Извлечение file_id и node_id
            figma_pattern = r'figma\.com/(?:file|proto|design)/([A-Za-z0-9]+)/[^?]*(?:\?[^#]*)?(?:#([A-Za-z0-9%-]+))?'
            match = re.search(figma_pattern, url)
            
            if not match:
                return None
            
            file_id = match.group(1)
            node_id = match.group(2) if match.group(2) else None
            
            # Если node_id не указан, получаем информацию о файле для поиска первого фрейма
            if not node_id:
                file_info_url = f"https://api.figma.com/v1/files/{file_id}"
                headers = {"X-Figma-Token": self.figma_token}
                
                async with session.get(file_info_url, headers=headers) as response:
                    if response.status == 200:
                        file_data = await response.json()
                        # Ищем первый фрейм в документе
                        node_id = self._find_first_frame_id(file_data.get("document", {}))
                        if not node_id:
                            node_id = "0:1"  # Fallback на первый узел
                    else:
                        node_id = "0:1"  # Fallback на первый узел
            else:
                # Декодируем node_id если он закодирован
                node_id = urllib.parse.unquote(node_id)
            
            print(f"🎨 Figma: file_id={file_id}, node_id={node_id}")
            
            # API запрос к Figma
            api_url = f"https://api.figma.com/v1/images/{file_id}"
            params = {"ids": node_id, "format": "png", "scale": 2}
            headers = {"X-Figma-Token": self.figma_token}
            
            async with session.get(api_url, params=params, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    image_url = data.get("images", {}).get(node_id)
                    
                    if image_url:
                        return await self._download_image(session, image_url)
                    else:
                        print(f"❌ Не удалось получить изображение для node_id: {node_id}")
                        
        except Exception as e:
            print(f"❌ Ошибка Figma API: {e}")
        
        return None

    async def _download_image(self, session: aiohttp.ClientSession, image_url: str) -> Optional[bytes]:
        """Скачивание изображения"""
        try:
            timeout = aiohttp.ClientTimeout(total=30)
            async with session.get(image_url, timeout=timeout) as response:
                if response.status == 200:
                    return await response.read()
        except Exception as e:
            print(f"❌ Ошибка скачивания изображения: {e}")
        
        return None

    async def _download_image_with_headers(self, session: aiohttp.ClientSession, image_url: str, headers: dict) -> Optional[bytes]:
        """Скачивание изображения с заголовками"""
        try:
            timeout = aiohttp.ClientTimeout(total=30)
            async with session.get(image_url, headers=headers, timeout=timeout) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    print(f"❌ Ошибка HTTP: {response.status} для {image_url}")
        except Exception as e:
            print(f"❌ Ошибка скачивания изображения с заголовками: {e}")
        
        return None

    async def _get_yandex_disk_preview(self, session: aiohttp.ClientSession, url: str) -> Optional[bytes]:
        """Получение превью из Яндекс.Диска"""
        try:
            # Если это уже прямая ссылка на изображение
            if url.endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp')):
                print(f"✅ Прямая ссылка на изображение: {url}")
                return await self._download_image(session, url)
            
            # Если это ссылка на файл в Яндекс.Диск
            if 'disk.yandex.ru' in url:
                # Пробуем получить прямую ссылку
                if '/d/' in url:
                    download_url = url.replace('/d/', '/i/')
                    print(f"✅ Преобразована ссылка /d/ в /i/: {download_url}")
                elif '/i/' in url:
                    # Это уже прямая ссылка на изображение
                    download_url = url
                    print(f"✅ Используем прямую ссылку /i/: {download_url}")
                else:
                    # Пробуем как есть
                    download_url = url
                    print(f"✅ Используем оригинальную ссылку: {download_url}")
                
                print(f"🔍 Попытка загрузки Яндекс.Диск: {download_url}")
                
                # Добавляем заголовки для обхода ограничений
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                    'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                }
                
                data = await self._download_image_with_headers(session, download_url, headers)
                if data:
                    print(f"✅ Получены данные изображения: {len(data)} байт")
                    return data
                else:
                    print(f"❌ Не удалось загрузить изображение по URL: {download_url}")
            
            # Если это ссылка через API
            if 'cloud-api.yandex.net' in url:
                print(f"✅ API ссылка Яндекс.Диск: {url}")
                data = await self._download_image(session, url)
                if data:
                    print(f"✅ Получены данные через API: {len(data)} байт")
                    return data
                else:
                    print(f"❌ Не удалось загрузить изображение через API")
                
        except Exception as e:
            print(f"❌ Ошибка Яндекс.Диск превью: {e}")
        
        print(f"❌ Не удалось получить превью для Яндекс.Диск: {url}")
        return None

    async def _upload_to_yandex_disk(self, session: aiohttp.ClientSession, image_data: bytes, title: str, url_type: str) -> Optional[str]:
        """Загрузка на Яндекс.Диск"""
        if not self.yandex_token:
            return None
            
        try:
            # Создание папки если нужно
            if url_type == "figma":
                await self._create_yandex_folder(session, "/figma")
            elif url_type == "screenshot":
                await self._create_yandex_folder(session, "/screenshots")
            elif url_type == "yandex_preview":
                await self._create_yandex_folder(session, "/previews")
            
            # Генерация уникального имени файла
            timestamp = int(time.time() * 1000000)  # микросекунды
            random_num = random.randint(1000, 9999)
            safe_title = re.sub(r'[^\w\s-]', '', title)[:30]
            filename = f"{safe_title}_{url_type}_{timestamp}_{random_num}.png"
            
            if url_type == "figma":
                yandex_path = f"/figma/{filename}"
            elif url_type == "screenshot":
                yandex_path = f"/screenshots/{filename}"
            elif url_type == "yandex_preview":
                yandex_path = f"/previews/{filename}"
            else:
                yandex_path = f"/{url_type}/{filename}"
            
            # Получение URL для загрузки
            upload_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/upload"
            params = {"path": yandex_path, "overwrite": "true"}
            headers = {"Authorization": f"OAuth {self.yandex_token}"}
            
            async with session.get(upload_url_api, params=params, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    upload_url = data.get("href")
                    
                    if upload_url:
                        # Загрузка файла
                        async with session.put(upload_url, data=image_data) as upload_response:
                            if upload_response.status in [201, 202]:
                                # Получение публичной ссылки
                                return await self._get_yandex_public_url(session, yandex_path)
                                
        except Exception as e:
            print(f"❌ Ошибка загрузки на Яндекс.Диск: {e}")
        
        return None

    async def _get_yandex_public_url(self, session: aiohttp.ClientSession, path: str) -> Optional[str]:
        """Получение публичной ссылки Яндекс.Диска"""
        try:
            # Получаем прямую ссылку на скачивание
            download_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/download"
            params = {"path": path}
            headers = {"Authorization": f"OAuth {self.yandex_token}"}
            
            async with session.get(download_url_api, params=params, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    download_url = data.get("href")
                    
                    if download_url:
                        # Возвращаем прямую ссылку на скачивание - Notion сможет её загрузить
                        return download_url
                    
        except Exception as e:
            print(f"❌ Ошибка получения ссылки на скачивание: {e}")
        
        return None

    async def _get_yandex_direct_url(self, session: aiohttp.ClientSession, url: str) -> Optional[str]:
        """Получение прямой ссылки на скачивание для Яндекс.Диск URL"""
        try:
            # Извлекаем путь из URL
            if '/i/' in url:
                # Это прямая ссылка на изображение, получаем через API публичную ссылку
                file_id = url.split('/i/')[-1]
                
                # Сначала пробуем получить через API публичную ссылку
                public_url_api = f"https://cloud-api.yandex.net/v1/disk/public/resources"
                params = {"public_key": url}
                headers = {"Authorization": f"OAuth {self.yandex_token}"}
                
                try:
                    async with session.get(public_url_api, params=params, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            # Получаем URL для предпросмотра
                            preview_url = data.get("preview")
                            if preview_url:
                                print(f"✅ Получен URL предпросмотра для Яндекс.Диск")
                                return preview_url
                except Exception as e:
                    print(f"⚠️ Не удалось получить предпросмотр через API: {e}")
                
                # Если не удалось получить через API, возвращаем оригинальную ссылку
                return url
                
            elif '/d/' in url:
                # Это ссылка на файл, нужно получить прямую ссылку
                file_path = url.split('/d/')[-1]
                # Декодируем URL
                file_path = urllib.parse.unquote(file_path)
                
                # Получаем прямую ссылку через API
                download_url_api = f"https://cloud-api.yandex.net/v1/disk/resources/download"
                params = {"path": f"disk:/{file_path}"}
                headers = {"Authorization": f"OAuth {self.yandex_token}"}
                
                async with session.get(download_url_api, params=params, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        download_url = data.get("href")
                        if download_url:
                            return download_url
                    else:
                        print(f"❌ Ошибка API Яндекс.Диск: {response.status}")
            
            # Проверяем, может это публичная ссылка
            if "yandex.ru/d/" in url:
                # Это публичная ссылка, пробуем получить предпросмотр
                public_url_api = f"https://cloud-api.yandex.net/v1/disk/public/resources"
                params = {"public_key": url}
                headers = {"Authorization": f"OAuth {self.yandex_token}"}
                
                try:
                    async with session.get(public_url_api, params=params, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            # Получаем URL для предпросмотра
                            preview_url = data.get("preview")
                            if preview_url:
                                print(f"✅ Получен URL предпросмотра для публичной ссылки")
                                return preview_url
                except Exception as e:
                    print(f"⚠️ Не удалось получить предпросмотр для публичной ссылки: {e}")
            
            # Fallback - возвращаем оригинальную ссылку
            return url
            
        except Exception as e:
            print(f"❌ Ошибка получения прямой ссылки Яндекс.Диск: {e}")
            return url

    async def _update_record_cover(self, session: aiohttp.ClientSession, record_id: str, image_url: str):
        """Обновление обложки записи"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{record_id}"
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Content-Type": "application/json",
                "Notion-Version": "2022-06-28"
            }
            
            payload = {
                "cover": {
                    "type": "external",
                    "external": {"url": image_url}
                }
            }
            
            async with session.patch(url, headers=headers, json=payload) as response:
                if response.status == 200:
                    print(f"✅ Обложка обновлена для записи {record_id}")
                else:
                    print(f"❌ Ошибка обновления обложки: {response.status}")
                    
        except Exception as e:
            print(f"❌ Ошибка обновления обложки: {e}")

    async def _add_to_files_media(self, session: aiohttp.ClientSession, record_id: str, file_url: str, title: str):
        """Добавление файла в поле Files & media"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{record_id}"
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Content-Type": "application/json",
                "Notion-Version": "2022-06-28"
            }
            
            payload = {
                "properties": {
                    "Files & media": {
                        "files": [
                            {
                                "type": "external",
                                "name": f"Превью - {title}",
                                "external": {"url": file_url}
                            }
                        ]
                    }
                }
            }
            
            async with session.patch(url, headers=headers, json=payload) as response:
                if response.status == 200:
                    print(f"✅ Файл добавлен в Files & media для записи {record_id}")
                else:
                    print(f"❌ Ошибка добавления файла: {response.status}")
                    
        except Exception as e:
            print(f"❌ Ошибка добавления в Files & media: {e}")

    async def _create_material_record(self, session: aiohttp.ClientSession, record_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Создание новой записи в базе материалов"""
        try:
            # Подготавливаем данные для создания (только обязательные поля)
            properties = {
                "Name": {
                    "title": [
                        {
                            "text": {
                                "content": record_data.get("Name", "Новая запись")
                            }
                        }
                    ]
                },
                "URL": {
                    "url": record_data.get("URL", "")
                },
                "Files & media": {
                    "files": []
                }
            }
            
            # Создаем запись
            create_data = {
                "parent": {
                    "database_id": self.materials_db
                },
                "properties": properties
            }
            
            url = f"{self.cloudflare_proxy}/v1/pages"
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Content-Type": "application/json",
                "Notion-Version": "2022-06-28"
            }
            
            async with session.post(url, headers=headers, json=create_data) as response:
                if response.status == 200:
                    created_record = await response.json()
                    print(f"✅ Запись создана: {created_record.get('id')}")
                    return created_record
                else:
                    print(f"❌ Ошибка создания записи: {response.status}")
                    error_text = await response.text()
                    print(f"   Детали: {error_text}")
                    return None
                    
        except Exception as e:
            print(f"❌ Ошибка создания записи: {e}")
            return None

    async def _get_record_by_id(self, session: aiohttp.ClientSession, record_id: str) -> Optional[Dict[str, Any]]:
        """Получение записи по ID"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{record_id}"
            headers = {
                "Authorization": f"Bearer {self.notion_token}",
                "Notion-Version": "2022-06-28"
            }
            
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    print(f"❌ Ошибка получения записи: {response.status}")
                    return None
                    
        except Exception as e:
            print(f"❌ Ошибка получения записи: {e}")
            return None 