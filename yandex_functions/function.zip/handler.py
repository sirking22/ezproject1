#!/usr/bin/env python3
"""
🚀 NOTION WEBHOOK HANDLER
Автоматическая обработка событий Notion через webhooks
"""

import os
import json
import asyncio
import aiohttp
import re
from datetime import datetime
from typing import Dict, Any, Optional

def log(msg: str, level: str = "INFO"):
    """Логирование"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] [{level}] {msg}")

class NotionWebhookHandler:
    """Обработчик Notion webhooks с полной логикой обработки обложек"""

    def __init__(self):
        self.notion_token = os.environ.get("NOTION_TOKEN")
        self.materials_db = os.environ.get("MATERIALS_DB")
        self.cloudflare_proxy = os.environ.get("CLOUDFLARE_PROXY", "https://delicate-hat-c01b.e1vice.workers.dev")
        self.yandex_disk_token = os.environ.get("YANDEX_DISK_TOKEN")
        self.figma_token = os.environ.get("FIGMA_TOKEN")

        # Полные заголовки для обхода Cloudflare
        self.headers = {
            "Authorization": f"Bearer {self.notion_token}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9,ru;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "cross-site",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Sec-Ch-Ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Upgrade-Insecure-Requests": "1",
            "X-Requested-With": "XMLHttpRequest"
        }

    async def handle_page_created(self, page_id: str, page_data: Dict[str, Any]):
        """Обработка создания новой страницы"""
        log(f"📄 Новая страница создана: {page_id}")

        # Проверяем, есть ли обложка
        if not page_data.get("cover"):
            log(f"🔍 Страница без обложки: {page_id}")
            await self.process_page_for_cover(page_id, page_data)

    async def handle_page_updated(self, page_id: str, page_data: Dict[str, Any]):
        """Обработка обновления страницы"""
        log(f"📝 Страница обновлена: {page_id}")

        # Проверяем изменения в обложке
        if "cover" in page_data.get("properties", {}):
            log(f"🎨 Обложка изменена: {page_id}")
            await self.process_page_for_cover(page_id, page_data)
        else:
            log(f"🔍 Обложка не изменена, но обрабатываем страницу: {page_id}")
            await self.process_page_for_cover(page_id, page_data)

    async def handle_database_updated(self, database_id: str):
        """Обработка обновления базы данных"""
        log(f"🗄️ База данных обновлена: {database_id}")

        if database_id == self.materials_db:
            log("🎯 Обновлена база 'Материалы' - проверяем новые записи")
            await self.check_materials_without_covers()

    async def process_page_for_cover(self, page_id: str, page_data: Dict[str, Any]):
        """Обработка страницы для добавления обложки"""
        try:
            # Получаем полные данные страницы
            page_info = await self.get_page_info(page_id)
            if not page_info:
                return

            # Ищем ссылки в разных полях
            links = []
            
            # 1. Поле "Name"
            content = page_info.get("properties", {}).get("Name", {}).get("title", [])
            if content:
                text = " ".join([block.get("plain_text", "") for block in content])
                links.extend(re.findall(r'https?://[^\s]+', text))
            
            # 2. Поле "URL"
            url_property = page_info.get("properties", {}).get("URL", {}).get("url")
            if url_property:
                links.append(url_property)
            
            # 3. Поле "Описание"
            description = page_info.get("properties", {}).get("Описание", {}).get("rich_text", [])
            if description:
                text = " ".join([block.get("plain_text", "") for block in description])
                links.extend(re.findall(r'https?://[^\s]+', text))

            log(f"🔗 Найдено ссылок: {len(links)}")
            
            # Обрабатываем каждую ссылку
            for link in links:
                log(f"🔗 Обрабатываем ссылку: {link}")
                await self.add_cover_from_link(page_id, link)

        except Exception as e:
            log(f"❌ Ошибка обработки страницы {page_id}: {e}", "ERROR")

    async def add_cover_from_link(self, page_id: str, link: str):
        """Добавление обложки из ссылки"""
        try:
            # Получаем изображение из ссылки
            image_url = await self.get_image_from_link(link)
            if not image_url:
                log(f"❌ Не удалось получить изображение из ссылки: {link}")
                return

            log(f"✅ Получено изображение: {image_url}")

            # Загружаем на Яндекс.Диск и получаем ссылки
            cover_url, file_url = await self.upload_to_yandex_disk_and_get_urls(image_url, page_id)
            
            if cover_url:
                # Обновляем обложку
                success = await self.update_notion_cover(page_id, cover_url)
                if success:
                    log(f"✅ Обложка обновлена: {page_id}")
                else:
                    log(f"❌ Ошибка обновления обложки: {page_id}")
            
            if file_url:
                # Обновляем Files & media
                success = await self.update_notion_files_media(page_id, file_url)
                if success:
                    log(f"✅ Files & media обновлены: {page_id}")
                else:
                    log(f"❌ Ошибка обновления Files & media: {page_id}")

        except Exception as e:
            log(f"❌ Ошибка добавления обложки для {page_id}: {e}", "ERROR")

    async def get_image_from_link(self, link: str) -> Optional[str]:
        """Получение изображения из ссылки"""
        try:
            # Figma ссылки
            if "figma.com" in link:
                return await self.get_figma_preview(link)
            
            # LightShot ссылки
            elif "prnt.sc" in link or "lightshot.cc" in link:
                return await self.get_lightshot_image(link)
            
            # Яндекс.Диск ссылки
            elif "disk.yandex.ru" in link:
                return await self.get_yandex_disk_image(link)
            
            # Прямые ссылки на изображения
            elif any(ext in link.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp']):
                return link
            
            # Imgur ссылки
            elif "imgur.com" in link or "i.imgur.com" in link:
                return link
            
            # ibb.co ссылки
            elif "ibb.co" in link:
                return link
            
            else:
                log(f"❌ Неподдерживаемый тип ссылки: {link}")
                return None

        except Exception as e:
            log(f"❌ Ошибка получения изображения из {link}: {e}", "ERROR")
            return None

    async def get_figma_preview(self, figma_url: str) -> Optional[str]:
        """Получение превью из Figma"""
        try:
            # Извлекаем file_key и node_id из URL
            match = re.search(r'figma\.com/file/([a-zA-Z0-9]+)/([^?]+)', figma_url)
            if not match:
                log(f"❌ Неверный формат Figma URL: {figma_url}")
                return None
            
            file_key = match.group(1)
            node_id = match.group(2).split('/')[-1]
            
            log(f"🔍 Figma file_key: {file_key}, node_id: {node_id}")
            
            # Получаем изображение через Figma API
            url = f"https://api.figma.com/v1/images/{file_key}?ids={node_id}&format=png"
            headers = {"X-Figma-Token": self.figma_token}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        # Ищем изображение по node_id (пробуем оба формата)
                        possible_keys = [node_id, node_id.replace('-', ':'), node_id.replace(':', '-')]
                        log(f"🔍 Ищем ключи: {possible_keys}")
                        
                        for key in possible_keys:
                            if key in data['images']:
                                image_url = data['images'][key]
                                if image_url and image_url != "null":
                                    log(f"✅ Найдено изображение Figma: {image_url}")
                                    return image_url
                        
                        log(f"❌ Node ID {node_id} не найден в ответе")
                        return None
                    else:
                        log(f"❌ Ошибка Figma API: {response.status}")
                        return None

        except Exception as e:
            log(f"❌ Ошибка получения Figma превью: {e}", "ERROR")
            return None

    async def get_lightshot_image(self, url: str) -> Optional[str]:
        """Получение изображения из LightShot"""
        try:
            log(f"🔍 Получаем изображение из LightShot: {url}")
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        html = await response.text()
                        
                        # Ищем прямую ссылку на изображение
                        img_match = re.search(r'<img[^>]+src="([^"]+)"[^>]*class="no-click screenshot-image"', html)
                        if img_match:
                            image_url = img_match.group(1)
                            if image_url.startswith('//'):
                                image_url = 'https:' + image_url
                            log(f"✅ Найдено изображение LightShot: {image_url}")
                            return image_url
                        
                        # Альтернативный поиск
                        img_match = re.search(r'<img[^>]+src="([^"]+\.png)"', html)
                        if img_match:
                            image_url = img_match.group(1)
                            if image_url.startswith('//'):
                                image_url = 'https:' + image_url
                            log(f"✅ Найдено изображение LightShot (альт): {image_url}")
                            return image_url
                        
                        log(f"❌ Не найдено изображение в LightShot: {url}")
                        return None
                    else:
                        log(f"❌ Ошибка получения LightShot: {response.status}")
                        return None

        except Exception as e:
            log(f"❌ Ошибка получения LightShot изображения: {e}", "ERROR")
            return None

    async def get_yandex_disk_image(self, url: str) -> Optional[str]:
        """Получение изображения из Яндекс.Диск"""
        try:
            log(f"🔍 Получаем изображение из Яндекс.Диск: {url}")
            
            # Извлекаем путь к файлу из URL
            match = re.search(r'disk\.yandex\.ru/i/([^?]+)', url)
            if match:
                file_path = match.group(1)
                log(f"🔍 Путь к файлу: {file_path}")
                return url  # Возвращаем исходную ссылку для загрузки
            else:
                log(f"❌ Неверный формат Яндекс.Диск URL: {url}")
                return None

        except Exception as e:
            log(f"❌ Ошибка получения Яндекс.Диск изображения: {e}", "ERROR")
            return None

    async def upload_to_yandex_disk_and_get_urls(self, image_url: str, page_id: str) -> tuple[Optional[str], Optional[str]]:
        """Загрузка изображения на Яндекс.Диск и получение ссылок"""
        try:
            log(f"📤 Загружаем изображение на Яндекс.Диск: {image_url}")
            
            # Скачиваем изображение
            async with aiohttp.ClientSession() as session:
                async with session.get(image_url) as response:
                    if response.status != 200:
                        log(f"❌ Ошибка скачивания изображения: {response.status}")
                        return None, None
                    
                    image_data = await response.read()
                    log(f"✅ Изображение скачано: {len(image_data)} байт")

            # Генерируем уникальное имя файла
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"notion_material_{page_id}_{timestamp}.png"
            
            # Загружаем на Яндекс.Диск
            upload_url = f"https://cloud-api.yandex.net/v1/disk/resources/upload?path=app:/notion_materials/{filename}&overwrite=true"
            headers = {"Authorization": f"OAuth {self.yandex_disk_token}"}
            
            async with aiohttp.ClientSession() as session:
                # Получаем URL для загрузки
                async with session.get(upload_url, headers=headers) as response:
                    if response.status != 200:
                        log(f"❌ Ошибка получения URL загрузки: {response.status}")
                        return None, None
                    
                    upload_data = await response.json()
                    href = upload_data.get("href")
                    
                    if not href:
                        log(f"❌ Не получен URL загрузки")
                        return None, None
                    
                    # Загружаем файл
                    async with session.put(href, data=image_data) as upload_response:
                        if upload_response.status != 201:
                            log(f"❌ Ошибка загрузки файла: {upload_response.status}")
                            return None, None
                        
                        log(f"✅ Файл загружен: {filename}")
                        
                        # Получаем ссылки
                        cover_url = await self._get_download_url(filename)
                        file_url = await self._get_preview_url(filename)
                        
                        return cover_url, file_url

        except Exception as e:
            log(f"❌ Ошибка загрузки на Яндекс.Диск: {e}", "ERROR")
            return None, None

    async def _get_download_url(self, filename: str) -> Optional[str]:
        """Получение ссылки для скачивания"""
        try:
            url = f"https://cloud-api.yandex.net/v1/disk/resources/download?path=app:/notion_materials/{filename}"
            headers = {"Authorization": f"OAuth {self.yandex_disk_token}"}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("href")
                    else:
                        log(f"❌ Ошибка получения ссылки скачивания: {response.status}")
                        return None

        except Exception as e:
            log(f"❌ Ошибка получения ссылки скачивания: {e}", "ERROR")
            return None

    async def _get_preview_url(self, filename: str) -> Optional[str]:
        """Получение ссылки для предпросмотра"""
        try:
            url = f"https://cloud-api.yandex.net/v1/disk/resources?path=app:/notion_materials/{filename}&fields=preview"
            headers = {"Authorization": f"OAuth {self.yandex_disk_token}"}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        preview = data.get("preview", {})
                        return preview.get("href")
                    else:
                        log(f"❌ Ошибка получения ссылки предпросмотра: {response.status}")
                        return None

        except Exception as e:
            log(f"❌ Ошибка получения ссылки предпросмотра: {e}", "ERROR")
            return None

    async def update_notion_cover(self, page_id: str, cover_url: str) -> bool:
        """Обновление обложки в Notion"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{page_id}"
            data = {
                "cover": {
                    "type": "external",
                    "external": {
                        "url": cover_url
                    }
                }
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.patch(url, headers=self.headers, json=data) as response:
                    if response.status == 200:
                        log(f"✅ Обложка обновлена успешно: {page_id}")
                        return True
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка обновления обложки {page_id}: {response.status} - {error_text}")
                        return False

        except Exception as e:
            log(f"❌ Ошибка обновления обложки {page_id}: {e}", "ERROR")
            return False

    async def update_notion_files_media(self, page_id: str, file_url: str) -> bool:
        """Обновление Files & media в Notion"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{page_id}"
            data = {
                "properties": {
                    "Files & media": {
                        "files": [
                            {
                                "name": "Material File",
                                "type": "external",
                                "external": {
                                    "url": file_url
                                }
                            }
                        ]
                    }
                }
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.patch(url, headers=self.headers, json=data) as response:
                    if response.status == 200:
                        log(f"✅ Files & media обновлены успешно: {page_id}")
                        return True
                    else:
                        error_text = await response.text()
                        log(f"❌ Ошибка обновления Files & media {page_id}: {response.status} - {error_text}")
                        return False

        except Exception as e:
            log(f"❌ Ошибка обновления Files & media {page_id}: {e}", "ERROR")
            return False

    async def get_page_info(self, page_id: str) -> Optional[Dict[str, Any]]:
        """Получение информации о странице"""
        try:
            url = f"{self.cloudflare_proxy}/v1/pages/{page_id}"
            log(f"🔍 [get_page_info] Запрос страницы: {page_id}")
            log(f"🔑 [get_page_info] Токен: {self.notion_token[:10] if self.notion_token else 'None'}...")
            log(f"🎯 [get_page_info] URL через прокси: {url}")
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=self.headers) as response:
                    log(f"✅ [get_page_info] Ответ от прокси: {response.status}")
                    if response.status == 200:
                        data = await response.json()
                        log(f"✅ [get_page_info] Данные получены успешно")
                        return data
                    else:
                        error_text = await response.text()
                        log(f"❌ [get_page_info] Ошибка получения страницы {page_id}: {response.status} - {error_text}")
                        return None

        except Exception as e:
            log(f"❌ [get_page_info] Ошибка запроса страницы {page_id}: {e}", "ERROR")
            return None

    async def check_materials_without_covers(self):
        """Проверка материалов без обложек"""
        try:
            url = f"{self.cloudflare_proxy}/v1/databases/{self.materials_db}/query"
            data = {
                "filter": {
                    "and": [
                        {
                            "property": "Name",
                            "title": {
                                "is_not_empty": True
                            }
                        },
                        {
                            "or": [
                                {
                                    "property": "Cover",
                                    "files": {
                                        "is_empty": True
                                    }
                                },
                                {
                                    "property": "Cover",
                                    "files": {
                                        "does_not_equal": ""
                                    }
                                }
                            ]
                        }
                    ]
                }
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=self.headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        pages = result.get("results", [])
                        log(f"🔍 Найдено материалов без обложек: {len(pages)}")
                        
                        for page in pages:
                            page_id = page["id"]
                            await self.process_page_for_cover(page_id, page)
                    else:
                        log(f"❌ Ошибка запроса материалов: {response.status}")

        except Exception as e:
            log(f"❌ Ошибка проверки материалов: {e}", "ERROR")

def handler(event, context):
    """Основная функция обработки webhook"""
    try:
        log("🚀 Webhook получен")
        
        # Получаем данные из события
        body = event.get("body", "")
        headers = event.get("headers", {})
        
        log(f"📊 Content-Type: {headers.get('content-type', 'unknown')}")
        log(f"📊 Event keys: {list(event.keys())}")
        
        # Проверяем верификационный запрос
        if headers.get("content-type", "").startswith("application/json") or "type" in event or "type" in body:
            try:
                # Пробуем разные способы получения данных
                if isinstance(body, str):
                    webhook_data = json.loads(body)
                elif isinstance(body, dict):
                    webhook_data = body
                else:
                    webhook_data = event
                
                log(f"📊 Body: {body[:200]}...")
                log(f"📊 Тип события: {webhook_data.get('type')}")
                log(f"📊 ID объекта: {webhook_data.get('object_id')}")
                
                # Обрабатываем верификационный запрос
                if webhook_data.get("type") == "url_verification":
                    challenge = webhook_data.get("challenge")
                    log(f"🔐 Верификация webhook: {challenge}")
                    return {
                        "statusCode": 200,
                        "headers": {
                            "Content-Type": "application/json"
                        },
                        "body": json.dumps({"challenge": challenge})
                    }
                
                # Обрабатываем обычные события
                handler_instance = NotionWebhookHandler()
                event_type = webhook_data.get("type")
                object_id = webhook_data.get("object_id")
                
                if event_type == "page.created" and object_id:
                    asyncio.run(handler_instance.handle_page_created(str(object_id), webhook_data))
                elif event_type == "page.updated" and object_id:
                    asyncio.run(handler_instance.handle_page_updated(str(object_id), webhook_data))
                elif event_type == "database.updated" and object_id:
                    asyncio.run(handler_instance.handle_database_updated(str(object_id)))
                else:
                    log(f"ℹ️ Неизвестный тип события: {event_type}")
                
                return {
                    "statusCode": 200,
                    "headers": {
                        "Content-Type": "application/json"
                    },
                    "body": json.dumps({"status": "success"})
                }
                
            except Exception as e:
                log(f"❌ Ошибка обработки webhook: {e}", "ERROR")
                return {
                    "statusCode": 500,
                    "headers": {
                        "Content-Type": "application/json"
                    },
                    "body": json.dumps({"error": str(e)})
                }
        else:
            log(f"ℹ️ Неизвестный Content-Type: {headers.get('content-type')}")
            return {
                "statusCode": 400,
                "headers": {
                    "Content-Type": "application/json"
                },
                "body": json.dumps({"error": "Invalid content type"})
            }
            
    except Exception as e:
        log(f"❌ Критическая ошибка handler: {e}", "ERROR")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": str(e)})
        }
